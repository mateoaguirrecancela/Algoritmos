# Algoritmos

Prácticas Algoritmos (curso 2020/21)

## Calificaciones

- **Práctica 1:** *8'50*
- **Práctica 2:** *9'50*
- **Práctica 3:** *8'50*
- **Práctica 4:** *8'50*
- **Examen:** *7'00*
